﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;

namespace _3_days_to_code
{
    public partial class Student_Check_Payment : Form
    {
        OleDbConnection connect = new OleDbConnection();
        OleDbCommand cmd = new OleDbCommand();
        
        public Student_Check_Payment()
        {
            InitializeComponent();
            connect.ConnectionString = "Provider = Microsoft.JET.OLEDB.4.0; Data Source = IOOP.mdb";
            connect.Open(); 
        }

        private void button6_Click(object sender, EventArgs e)
        {
            connect.Close();
            connect.Open();
            cmd.CommandText = "select * from User_Data where UserID = '" + textBox1.Text + "'";
            cmd.Connection = connect;

            OleDbDataReader reader = cmd.ExecuteReader();
            if (reader.Read() == true)
            {

                reader.Close();

                cmd.CommandText = "SELECT count(Student_ID) as Subject_Amount, Student_ID FROM Subject_Count group by Student_ID having Student_ID = '"+ textBox1.Text +"'";
                cmd.Connection = connect;

                //Load Data in Database
                OleDbDataReader reader_1 = cmd.ExecuteReader();


                //reader type is boolean
                if (reader_1.Read() == true)
                {

                    textBox1.Text = reader_1[1].ToString();
                    textBox5.Text = reader_1[0].ToString();


                    if (int.Parse(reader_1[0].ToString()) == 1)
                    {
                        reader_1.Close();

                        cmd.CommandText = "SELECT Class_ID FROM Subject_Count where Student_ID = '" + textBox1.Text + "'";
                        cmd.Connection = connect;

                        //Load Data in Database
                        OleDbDataReader reader_2 = cmd.ExecuteReader();

                        //reader type is boolean
                        if (reader_2.Read() == true)
                        {
                            cmd.CommandText = "SELECT Sum(Fee) as TOTAL FROM Class group by Class_ID having Class_ID = '" + reader_2[0].ToString() + "'";
                            cmd.Connection = connect;

                            reader_2.Close();

                            //Load Data in Database
                            OleDbDataReader reader_3 = cmd.ExecuteReader();

                            //reader type is boolean
                            if (reader_3.Read() == true)
                            {
                                textBox3.Text = reader_3[0].ToString();
                            }
                        }

                    }

                    else if (int.Parse(reader_1[0].ToString()) > 1)
                    {
                        reader_1.Close();

                        cmd.CommandText = "SELECT Class_ID FROM Subject_Count where Student_ID = '" + textBox1.Text + "'";
                        cmd.Connection = connect;

                        //Load Data in Database
                        OleDbDataReader reader_2 = cmd.ExecuteReader();

                        //reader type is boolean
                        if (reader_2.Read() == true)
                        {
                            reader_2.Close();

                            cmd.CommandText = "SELECT top 3 Subject_Count.Class_ID FROM Subject_Count where Subject_Count.Student_ID = '" + textBox1.Text + "' order by Subject_Count.Class_ID ASC";
                            cmd.Connection = connect;

                            //Load Data in Database
                            OleDbDataReader reader_3 = cmd.ExecuteReader();

                            //reader type is boolean
                            if (reader_3.Read() == true)

                            cmd.CommandText = "SELECT Sum(Fee) as TOTAL FROM Class group by Class_ID having Class_ID = '" + reader_3[0].ToString() + "'";
                            cmd.Connection = connect;

                            reader_3.Close();

                            //Load Data in Database
                            OleDbDataReader reader_4 = cmd.ExecuteReader();

                            //reader type is boolean
                            if (reader_4.Read() == true)
                            {
                                string first_sum = reader_4[0].ToString();

                                cmd.CommandText = "SELECT top 3 Subject_Count.Class_ID FROM Subject_Count where Subject_Count.Student_ID = '"+ textBox1.Text +"' order by Subject_Count.Class_ID DESC";
                                cmd.Connection = connect;

                                reader_4.Close();

                                //Load Data in Database
                                OleDbDataReader reader_5 = cmd.ExecuteReader();

                                //reader type is boolean
                                if (reader_5.Read() == true)
                                {
                                    cmd.CommandText = "SELECT Sum(Fee) as TOTAL FROM Class group by Class_ID having Class_ID = '" + reader_4[0].ToString() + "'";
                                    cmd.Connection = connect;

                                    reader_5.Close();

                                    //Load Data in Database
                                    OleDbDataReader reader_6 = cmd.ExecuteReader();

                                    //reader type is boolean
                                    if (reader_6.Read() == true)
                                    {
                                        int total_sum = int.Parse(first_sum) + int.Parse(reader_6[0].ToString());

                                        textBox3.Text = total_sum.ToString();

                                        cmd.CommandText = "SELECT Sum(Payment_Amount) as TOTAL FROM Payment group by Student_ID having Student_ID = '" + textBox1.Text + "'";
                                        cmd.Connection = connect;

                                        reader_6.Close();

                                        //Load Data in Database
                                        OleDbDataReader reader_7 = cmd.ExecuteReader();

                                        //reader type is boolean
                                        if (reader_7.Read() == true)
                                        {
                                            int overdue_payment = total_sum - int.Parse(reader_7[0].ToString());
                                            textBox7.Text = overdue_payment.ToString();
                                            reader_7.Close();
                                        }
                                    }

                                    
                                }

                                
                            }
                        }
                    }

                    else
                    {
                        MessageBox.Show("Zero Subject");
                        reader_1.Close();
                    }
                    
                }

            }

            else
            {
                MessageBox.Show("Student not found");
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Log_In newform = new Log_In();
            this.Hide();
            newform.ShowDialog();
            this.Show();
        }

        private void button1_Click(object sender, EventArgs e)
        {
                Student_Dashboard newform = new Student_Dashboard();
                this.Hide();
                newform.ShowDialog();
                this.Show();

           
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Student_Update_Profile newform = new Student_Update_Profile();
            this.Hide();
            newform.ShowDialog();
            this.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Student_Class newform = new Student_Class();
            this.Hide();
            newform.ShowDialog();
            this.Show();
        }

        //watermark for TP Number column
        private void textBox1_Enter(object sender, EventArgs e)
        {

            if (textBox1.Text == "TP012345")
            {
                textBox1.Text = "";

                textBox1.ForeColor = Color.Black;
            }
        }

        //watermark for TP Number column
        private void textBox1_leave(object sender, EventArgs e)
        {
            if (textBox1.Text == "")
            {
                textBox1.Text = "TP012345";

                textBox1.ForeColor = Color.Silver;
            }
        }


        //watermark for amount column
        private void textBox3_Enter(object sender, EventArgs e)
        {
            if (textBox3.Text == "More Than 0")
            {
                textBox3.Text = "";

                textBox3.ForeColor = Color.Black;
            }
        }

        //watermark for amount column
        private void textBox3_leave(object sender, EventArgs e)
        {
            if (textBox3.Text == "")
            {
                textBox3.Text = "More Than 0";

                textBox3.ForeColor = Color.Silver;
            }
        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
        
}
