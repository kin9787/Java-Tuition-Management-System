﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

//database library
using System.Data.OleDb;

namespace _3_days_to_code
{
    public partial class Staff_Dashboard : Form
    {

        //set up connection for database
        OleDbConnection connect = new OleDbConnection();
        OleDbCommand cmd = new OleDbCommand();

        public Staff_Dashboard()
        {
            InitializeComponent();
        }

        private void Form2_Load(object sender, EventArgs e)
        {

            //setting up database 
            connect.ConnectionString = "Provider = Microsoft.JET.OLEDB.4.0; Data Source = IOOP.mdb";

            //connect to database
            connect.Open();

            //Query Commands (Select Staff Username from Database)
            cmd.CommandText = "select * from User_Data where UserID = '" + keys.name_for_dashboard + "'";
            cmd.Connection = connect;

            //Load Data in Database
            OleDbDataReader reader = cmd.ExecuteReader();

            //reader type is boolean
            if (reader.Read() == true)
            {
                label4.Text = reader[2].ToString() + reader[3].ToString();
            }

            else
            {
                MessageBox.Show("Error in Label");
            }

            //changing background theme
            label1.Parent = pictureBox1;
            label3.Parent = pictureBox1;
            label5.Parent = pictureBox1;
        }

        //take user to student registration
        private void button1_Click_1(object sender, EventArgs e)
        {
            Student_Registration newform = new Student_Registration();
            this.Hide();
            newform.ShowDialog();
            this.Show();
        }

        //log off
        private void button4_Click(object sender, EventArgs e)
        {
            Log_In newform = new Log_In();
            this.Hide();
            newform.ShowDialog();
            this.Show();
        }

        //take user to student payment form
        private void button2_Click(object sender, EventArgs e)
        {
            Staff_Student_Payment newform = new Staff_Student_Payment();
            this.Hide();
            newform.ShowDialog();
            this.Show();
        }

        //take user to check class schedule
        private void button3_Click(object sender, EventArgs e)
        {
            Staff_Class newform = new Staff_Class();
            this.Hide();
            newform.ShowDialog();
            this.Show();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            Staff_Check_Payment newform = new Staff_Check_Payment();
            this.Hide();
            newform.ShowDialog();
            this.Show();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            Staff_Enroll_More__Subjects newform = new Staff_Enroll_More__Subjects();
            this.Hide();
            newform.ShowDialog();
            this.Show();
        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
    }
