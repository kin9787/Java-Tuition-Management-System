﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

//library for database
using System.Data.OleDb;

namespace _3_days_to_code
{
    public partial class Staff_Student_Payment : Form
    {
        //set up connection for database
        OleDbConnection connect = new OleDbConnection();
        OleDbCommand cmd = new OleDbCommand();

        public Staff_Student_Payment()
        {
            InitializeComponent();

            //setting up database 
            connect.ConnectionString = "Provider = Microsoft.JET.OLEDB.4.0; Data Source = IOOP.mdb";

            //connect to database
            connect.Open(); 
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //take user to staff dashboard
            Staff_Dashboard newform = new Staff_Dashboard();
            this.Hide();
            newform.ShowDialog();
            this.Show();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            //log out 
            Log_In newform = new Log_In();
            this.Hide();
            newform.ShowDialog();
            this.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            //take user to student registration
            Student_Registration newform = new Student_Registration();
            this.Hide();
            newform.ShowDialog();
            this.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            //able user to check class
            Staff_Class newform = new Staff_Class();
            this.Hide();
            newform.ShowDialog();
            this.Show();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            //to capitalize all inputs
            string input_1 = Useful_Functions.FirstCharToUpper(textBox1.Text);
            string input_4 = Useful_Functions.FirstCharToUpper(textBox4.Text);
            
            //Query Commands (Select Staff Username from Database)
            cmd.CommandText = "select * from User_Data where [UserID] = '" + textBox2.Text + "'";
            cmd.Connection = connect;

            connect.Close();
            connect.Open();

            //Load Data in Database
            //first connection
            OleDbDataReader reader_1 = cmd.ExecuteReader();

            //reader type is boolean
            if (reader_1.Read() == true)
            {
                                                
                    //close reader
                    reader_1.Close();

                    //Query Commands (Select TP Number from Database)
                    cmd.CommandText = "select * from User_Data where [UserID] = '" + textBox1.Text + "'";
                    cmd.Connection = connect;

                    //Load Data in Database
                    //second connection
                    OleDbDataReader reader = cmd.ExecuteReader();

                    //reader type is boolean
                    if (reader.Read() == true)
                    {

                        reader.Close();

                        //to ensure the payment entered doesn't not less than 0
                        if (int.Parse(textBox3.Text) > 0)
                        {
                            //to check which class user picked
                            if (input_4 == "1" || input_4 == "2" || input_4 == "3" || input_4 == "4")                                             
                            {

                                cmd.CommandText = "select Payment_ID from Payment";
                                cmd.Connection = connect;

                                //Load Data in Database
                                OleDbDataReader reader_get_primary_key = cmd.ExecuteReader();

                                if (reader_get_primary_key.Read() == true)
                                {
                                    if (reader_get_primary_key[4].ToString() != null)
                                    {
                                        int previous_primary_key = int.Parse(reader_get_primary_key[4].ToString());
                                        int new_primary_key = previous_primary_key + 1;
                                        reader_get_primary_key.Close();

                                        cmd.CommandText = string.Format(@"insert into Payment values('{0}','{1}',{2},'{3}','{4}','{5}')", textBox2.Text, textBox1.Text, textBox3.Text, data.today, new_primary_key.ToString(), textBox4.Text);
                                        cmd.Connection = connect;
                                        cmd.ExecuteNonQuery();

                                        try { if (cmd.ExecuteNonQuery() == 1) ; }

                                        catch
                                        {
                                            //if succesfull make the payment
                                            MessageBox.Show("Success!");
                                            textBox1.Text = null;
                                            textBox2.Text = null;
                                            textBox3.Text = null;
                                            textBox4.Text = null;
                                            reader.Close();
                                        }

                                    keys.Student_ID = textBox1.Text;
                                    keys.Staff_Name = textBox2.Text;
                                    keys.Amount = textBox3.Text;
                                    keys.Class = textBox4.Text;

                                    //able user to check class
                                    Receipt newform = new Receipt();
                                    this.Hide();
                                    newform.ShowDialog();
                                    this.Show();


                                }

                                    else
                                    {
                                        MessageBox.Show("Payment_ID already exist.");
                                        reader_get_primary_key.Close();
                                    }
                                }

                                else
                                {
                                reader_get_primary_key.Close();

                                cmd.CommandText = string.Format(@"insert into Payment values('{0}','{1}',{2},'{3}','{4}','{5}')", textBox2.Text, textBox1.Text, textBox3.Text, data.today, "1", textBox4.Text);
                                cmd.Connection = connect;
                                cmd.ExecuteNonQuery();

                                try { if (cmd.ExecuteNonQuery() == 1) ; }

                                catch
                                {
                                    //if succesfull make the payment
                                    MessageBox.Show("Success!");
                                    textBox1.Text = null;
                                    textBox2.Text = null;
                                    textBox3.Text = null;
                                    textBox4.Text = null;
                                    reader.Close();
                                }

                                keys.Student_ID =textBox1.Text;
                                keys.Staff_Name = textBox2.Text;
                                keys.Amount = textBox3.Text;
                                keys.Class = textBox4.Text;

                                //able user to check class
                                Receipt newform = new Receipt();
                                this.Hide();
                                newform.ShowDialog();
                                this.Show();
                            }

                                                                
                            }

                            else
                            {
                                //if user insert invalid class
                                MessageBox.Show("This class doesn't exist.");
                                textBox4.Text = null;
                                reader.Close();
                            }



                        }

                        else
                        {
                            //if user insert invalid amount
                            MessageBox.Show("Invalid Amount, must be more than 0.");
                            textBox3.Text = null;
                            reader.Close();
                        }

                    }

                    else
                    {
                        //if user insert invalid Student Number
                        MessageBox.Show("Invalid Student Number.");
                        textBox1.Text = null;
                        reader.Close();
                    }
                    
                

                


            }
            else
            {
                //if user insert invalid staff name
                MessageBox.Show("Staff name not found.");
                textBox2.Text = null;
                reader_1.Close();
            }
            

        }

        //check payment button
        private void button6_Click(object sender, EventArgs e)
        {
            //close the connection from database
            connect.Close();

            //connect to database
            connect.Open();

            //Query commands
            cmd.CommandText = "select * from Payment where TP_Number = '" + textBox1.Text + "'";

            //set up connection
            cmd.Connection = connect;

            //read data from database
            OleDbDataReader reader = cmd.ExecuteReader();
            if (reader.Read() == true)
            {
                //load data into each textBoxes
                textBox1.Text = reader[1].ToString();
                textBox2.Text = reader[0].ToString();
                textBox3.Text = reader[2].ToString();
                textBox4.Text = reader[3].ToString();
            }

            else
            {
                //if database doesnt contain the student
                MessageBox.Show("Student not found");
            }
    
        }

        //watermark for TP Number column
        private void textBox1_Enter(object sender, EventArgs e)
        {
            
            if (textBox1.Text == "TP012345")
            {
                textBox1.Text = "";

                textBox1.ForeColor = Color.Black;
            }
        }

        //watermark for TP Number column
        private void textBox1_leave(object sender, EventArgs e)
        {
            if (textBox1.Text == "")
            {
                textBox1.Text = "TP012345";

                textBox1.ForeColor = Color.Silver;
            }
        }

        //watermark for staff name column
        private void textBox2_Enter(object sender, EventArgs e)
        {
            if (textBox2.Text == "Staff's Name")
            {
                textBox2.Text = "";

                textBox2.ForeColor = Color.Black;
            }
        }

        //watermark for staff name column
        private void textBox2_leave(object sender, EventArgs e)
        {
            if (textBox2.Text == "")
            {
                textBox2.Text = "Staff's Name";

                textBox2.ForeColor = Color.Silver;
            }
        }

        //watermark for amount column
        private void textBox3_Enter(object sender, EventArgs e)
        {
            if (textBox3.Text == "More Than 0")
            {
                textBox3.Text = "";

                textBox3.ForeColor = Color.Black;
            }
        }

        //watermark for amount column
        private void textBox3_leave(object sender, EventArgs e)
        {
            if (textBox3.Text == "")
            {
                textBox3.Text = "More Than 0";

                textBox3.ForeColor = Color.Silver;
            }
        }

        //watermark for class column
        private void textBox4_Enter(object sender, EventArgs e)
        {
            if (textBox4.Text == "1/ 2/ 3/ 4")
            {
                textBox4.Text = "";

                textBox4.ForeColor = Color.Black;
            }
        }

        //watermark for class column
        private void textBox4_leave(object sender, EventArgs e)
        {
            if (textBox4.Text == "")
            {
                textBox4.Text = "1/ 2/ 3/ 4";

                textBox4.ForeColor = Color.Silver;
            }
        }

        private void button7_Click(object sender, EventArgs e)
        {
            Staff_Enroll_More__Subjects newform = new Staff_Enroll_More__Subjects();
            this.Hide();
            newform.ShowDialog();
            this.Show();
        }

        [System.Runtime.InteropServices.DllImport("gdi32.dll")]
        public static extern long BitBlt(IntPtr hdcDest, int nXDest, int nYDest, int nWidth, int nHeight, IntPtr hdcSrc, int nXSrc, int nYSrc, int dwRop);
        private Bitmap memoryImage;

        private void PrintScreen()
        {
            Graphics mygraphics = this.CreateGraphics();
            Size s = this.Size;
            memoryImage = new Bitmap(s.Width, s.Height, mygraphics);
            Graphics memoryGraphics = Graphics.FromImage(memoryImage);
            IntPtr dc1 = mygraphics.GetHdc();
            IntPtr dc2 = memoryGraphics.GetHdc();
            BitBlt(dc2, 0, 0, this.ClientRectangle.Width, this.ClientRectangle.Height, dc1, 0, 0, 13369376);
            mygraphics.ReleaseHdc(dc1);
            memoryGraphics.ReleaseHdc(dc2);
        }

        private void printDocument1_PrintPage(object sender, System.Drawing.Printing.PrintPageEventArgs e)
        {
            e.Graphics.DrawImage(memoryImage,0,0);
        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
