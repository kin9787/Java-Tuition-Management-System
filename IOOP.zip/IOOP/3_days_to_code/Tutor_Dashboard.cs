﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

//database library
using System.Data.OleDb;

namespace _3_days_to_code
{
    public partial class Tutor_Dashboard : Form
    {
        //set up connection for database
        OleDbConnection connect = new OleDbConnection();
        OleDbCommand cmd = new OleDbCommand();

        public Tutor_Dashboard()
        {
            InitializeComponent();
        }

        //able user to check class schedule
        private void button1_Click(object sender, EventArgs e)
        {
            Tutor_Class newform = new Tutor_Class();
            this.Hide();
            newform.ShowDialog();
            this.Show();
        }

        private void Tutor_Dashboard_Load(object sender, EventArgs e)
        {

            //setting up database 
            connect.ConnectionString = "Provider = Microsoft.JET.OLEDB.4.0; Data Source = IOOP.mdb";

            //connect to database
            connect.Open();

            //Query Commands (Select Staff Username from Database)
            cmd.CommandText = "select * from User_Data where UserID = '" + keys.name_for_dashboard + "'";
            cmd.Connection = connect;

            //Load Data in Database
            OleDbDataReader reader = cmd.ExecuteReader();

            //reader type is boolean
            if (reader.Read() == true)
            {
                label4.Text = reader[2].ToString() + reader[3].ToString();
            }

            else
            {
                //if user is not found
                MessageBox.Show("Error in Label");
            }

            //set up label background theme
            label1.Parent = pictureBox1;
            label5.Parent = pictureBox1;
            label3.Parent = pictureBox1;
           
        }

        //log off
        private void button4_Click(object sender, EventArgs e)
        {
            Log_In newform = new Log_In();
            this.Hide();
            newform.ShowDialog();
            this.Show();
        }

        //able user to update profile
        private void button3_Click(object sender, EventArgs e)
        {
            Tutor_Update_Profile newform = new Tutor_Update_Profile();
            this.Hide();
            newform.ShowDialog();
            this.Show();
        }

        //able user to add classes
        private void button2_Click(object sender, EventArgs e)
        {
            Tutor_Add_Class newform = new Tutor_Add_Class();
            this.Hide();
            newform.ShowDialog();
            this.Show();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            Tutor_Check_Student newform = new Tutor_Check_Student();
            this.Hide();
            newform.ShowDialog();
            this.Show();
        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
