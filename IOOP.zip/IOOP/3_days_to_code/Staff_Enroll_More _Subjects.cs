﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using System.Data.OleDb;

namespace _3_days_to_code
{
    public partial class Staff_Enroll_More__Subjects : Form
    {
        OleDbConnection connect = new OleDbConnection();
        OleDbCommand cmd = new OleDbCommand();

        public Staff_Enroll_More__Subjects()
        {
            InitializeComponent();
        }

        private void Staff_Enroll_More__Subjects_Load(object sender, EventArgs e)
        {
            connect.ConnectionString = "Provider = Microsoft.JET.OLEDB.4.0; Data Source = IOOP.mdb";
            connect.Open();
        }

        //watermark for subject column
        private void textBox1_Enter(object sender, EventArgs e)
        {
            if (textBox1.Text == "(Student Number)-(Class Number) ")
            {
                textBox1.Text = "";

                textBox1.ForeColor = Color.Black;
            }
        }

        //watermark for subject column
        private void textBox1_Leave(object sender, EventArgs e)
        {
            if (textBox1.Text == "")
            {
                textBox1.Text = "(Student Number)-(Class Number) ";

                textBox1.ForeColor = Color.Silver;
            }
        }

        private void button7_Click(object sender, EventArgs e)
        {
            string query_1 = string.Format(@"insert into Subject_Count values('{0}','{1}','{2}')", textBox1.Text, textBox2.Text, textBox5.Text);

            //Query Commands 
            cmd.CommandText = query_1;

            //connect to database
            cmd.Connection = connect;

            //execute code
            cmd.ExecuteNonQuery();


            try { if (cmd.ExecuteNonQuery() == 1) ; }

            catch
            {
                MessageBox.Show("Success!");
                textBox1.Text = " ";
                textBox2.Text = " ";
                textBox3.Text = " ";
                textBox4.Text = " ";


            }
    }

        
        private void button8_Click(object sender, EventArgs e)
        {
            cmd.CommandText = "select count(Class_ID) from Enrollment_Data having Class_ID = '" + textBox1.Text + "'";
            cmd.Connection = connect;

            OleDbDataReader reader = cmd.ExecuteReader();
            if (reader.Read() == true)
            {
                textBox4.Text = reader[0].ToString();
            }

            else
            {
                MessageBox.Show("Class does not exits");
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Student_Registration newform = new Student_Registration();
            this.Hide();
            newform.ShowDialog();
            this.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Staff_Student_Payment newform = new Staff_Student_Payment();
            this.Hide();
            newform.ShowDialog();
            this.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Staff_Class newform = new Staff_Class();
            this.Hide();
            newform.ShowDialog();
            this.Show();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            Staff_Check_Payment newform = new Staff_Check_Payment();
            this.Hide();
            newform.ShowDialog();
            this.Show();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            Staff_Dashboard newform = new Staff_Dashboard();
            this.Hide();
            newform.ShowDialog();
            this.Show();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Log_In newform = new Log_In();
            this.Hide();
            newform.ShowDialog();
            this.Show();
        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
