﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

//library for database
using System.Data.OleDb;

namespace _3_days_to_code
{
    public partial class Tutor_Add_Class : Form
    {
        //set up connection for database
        OleDbConnection connect = new OleDbConnection();
        OleDbCommand cmd = new OleDbCommand();

        public Tutor_Add_Class()
        {
            InitializeComponent();
            
            //customizing datatimepicker
            dateTimePicker2.Format = DateTimePickerFormat.Time;
            dateTimePicker2.ShowUpDown = true;
            dateTimePicker4.Format = DateTimePickerFormat.Time;
            dateTimePicker4.ShowUpDown = true;

        }

        private void Add_Tutor_Load(object sender, EventArgs e)
        {
            //setting up database 
            connect.ConnectionString = "Provider = Microsoft.JET.OLEDB.4.0; Data Source = IOOP.mdb";
            
            //connect to database
            connect.Open();
            
            //setting up controls background
            tableLayoutPanel1.Parent = pictureBox1;
            label6.Parent = pictureBox1;
            label1.Parent = pictureBox1;
        }

        private void button5_Click(object sender, EventArgs e)
        {
            //to capitalize all inputs
            string input_1 = Useful_Functions.FirstCharToUpper(textBox1.Text);
            string input_2 = Useful_Functions.FirstCharToUpper(textBox2.Text);
            string input_3 = Useful_Functions.FirstCharToUpper(textBox3.Text);
            string input_4 = Useful_Functions.FirstCharToUpper(textBox4.Text);

            //add date and time into a variable
            //start date
            DateTime myDate = dateTimePicker1.Value.Date + dateTimePicker2.Value.TimeOfDay;
            
            //end date
            DateTime my_2_date = dateTimePicker3.Value.Date + dateTimePicker4.Value.TimeOfDay;

            //date span to find duration
            TimeSpan time_difference = my_2_date - myDate;

            Double total_minutes = time_difference.TotalMinutes;

            //today's date
            DateTime today = DateTime.Today;

            //today's name
            string day = System.DateTime.Now.ToString("dddd");


            //Query Commands (Select Tutor Username from Database)
            cmd.CommandText = "select * from User_Data where [UserID] = '" + textBox1.Text + "'";
            cmd.Connection = connect;

            //Load Data in Database
            OleDbDataReader reader = cmd.ExecuteReader();

            //reader type is boolean
            if (reader.Read() == true)
            {
                
                string tutor_name = reader[0].ToString();
                reader.Close();
                if (textBox1.Text == tutor_name)
                {                  
                        //to check which class user picked
                        if (input_3 == "1" || input_3 == "2" || input_3 == "3" || input_3 == "4")
                        {
                            //to check what venue user picked
                            if (input_4 == "Room 1" || input_4 == "Room 2" || input_4 == "Room 3" || input_4 == "Room 4")
                            {
                                //to check what time the user picked
                                if (dateTimePicker1.Value.Date >= today)
                                {

                                    if (int.Parse(textBox5.Text) > 0)
                                    {

                                        if (input_2 == "Math")
                                        {

                                            string subject_desciption = data.Math;
                
                                            //disconnect database
                                            connect.Close();

                                            //reconnect to database
                                            connect.Open();

                                            //Query Commands (Insert data into Database)
                                            cmd.CommandText = string.Format(@"insert into [Class] values('{0}','{1}','{2}','{3}','{4}','{5}','{6}',{7},'{8}','{9}')",textBox6.Text, input_3, "1", subject_desciption, day, myDate, input_4, total_minutes, textBox5.Text, input_1);

                                            //connect to database
                                            cmd.Connection = connect;


                                        try { if (cmd.ExecuteNonQuery() == 1) ; }

                                        catch
                                        {
                                            //show when successfully insert data
                                            MessageBox.Show("Success!");
                                            textBox1.Text = null;
                                            textBox2.Text = null;
                                            textBox3.Text = null;
                                            textBox4.Text = null;
                                            reader.Close();

                                        }


                                    }

                                        else if (input_2 == "English")
                                        {
                                            string subject_desciption = data.English;

                                            //disconnect database
                                            connect.Close();

                                            //reconnect to database
                                            connect.Open();

                                            //Query Commands (Insert data into Database)
                                            cmd.CommandText = string.Format(@"insert into Class values('{0}','{1}','{2}','{3}','{4}','{5}','{6}',{7},'{8}','{9}')", textBox6.Text, input_3, "2", subject_desciption, day, myDate, input_4, total_minutes, textBox5.Text, input_1);

                                            //connect to database
                                            cmd.Connection = connect;

                                            //execute command
                                            cmd.ExecuteNonQuery();

                                        try { if (cmd.ExecuteNonQuery() == 1) ; }
                                        catch {
                                            //show when successfully insert data
                                            MessageBox.Show("Success!");
                                            textBox1.Text = null;
                                            textBox2.Text = null;
                                            textBox3.Text = null;
                                            textBox4.Text = null;
                                            reader.Close();
                                        }

                                           
                                        }

                                        else
                                        {
                                            MessageBox.Show("Subject doesn't exist");
                                            reader.Close();
                                        }
                                    }
                                    
                                
                                    else
                                    {
                                        MessageBox.Show("Invalid amount");
                                        textBox5.Text = null;
                                        reader.Close();
                                    }                                                                   
                                                                    
                                }

                                else
                                {
                                    //If user chooses wrong date time
                                    MessageBox.Show("Invalid Date Time");
                                    reader.Close();
                                }

                            }

                            else
                            {
                                //if user insert invalid venue
                                MessageBox.Show("Please insert a valid venue.");
                                textBox4.Text = null;
                                reader.Close();
                            }
                        }

                        else
                        {
                            //If user insert invalid Class
                            MessageBox.Show("Please insert a valid class.");                           
                            textBox3.Text = null;
                            reader.Close();
                        }

                    
                }

            }

            else
            {
                //if user enter invalid username
                MessageBox.Show("User not found.");
                textBox1.Text = null;
                reader.Close();
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //take user to tutor dashboard
            Tutor_Dashboard newform = new Tutor_Dashboard();
            this.Hide();
            newform.ShowDialog();
            this.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            //take user to form that check class schedule
            Tutor_Class newform = new Tutor_Class();
            this.Hide();
            newform.Hide();
            newform.ShowDialog();
            this.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            //able user to update profile
            Tutor_Update_Profile newform = new Tutor_Update_Profile();
            this.Hide();
            newform.Hide();
            newform.ShowDialog();
            this.Show();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            //log off
            Log_In newform = new Log_In();
            this.Hide();
            newform.ShowDialog();
            this.Show();
        }

        //watermark for tutor name column
        private void textBox1_Enter(object sender, EventArgs e)
        {
            if (textBox1.Text == "Tutor's Name")
            {
                textBox1.Text = "";

                textBox1.ForeColor = Color.Black;
            }
        }

        //watermark for tutor name column
        private void textBox1_Leave(object sender, EventArgs e)
        {
            if (textBox1.Text == "")
            {
                textBox1.Text = "Tutor's Name";

                textBox1.ForeColor = Color.Silver;
            }
        }

        //watermark for subject column
        private void textBox2_Enter(object sender, EventArgs e)
        {

            if (textBox2.Text == "Math/ English")
            {
                textBox2.Text = "";

                textBox2.ForeColor = Color.Black;
            }
        }

        //watermark for subject column
        private void textBox2_leave(object sender, EventArgs e)
        {
            if (textBox2.Text == "")
            {
                textBox2.Text = "Math/ English";

                textBox2.ForeColor = Color.Silver;
            }
        }

        //watermark for class column
        private void textBox3_Enter(object sender, EventArgs e)
        {
            if (textBox3.Text == "1/  2/  3/  4")
            {
                textBox3.Text = "";

                textBox3.ForeColor = Color.Black;
            }
        }

        //watermark for class column
        private void textBox3_leave(object sender, EventArgs e)
        {
            if (textBox3.Text == "")
            {
                textBox3.Text = "1/  2/  3/  4";

                textBox3.ForeColor = Color.Silver;
            }
        }

        //watermark for venue column
        private void textBox4_Enter(object sender, EventArgs e)
        {
            if (textBox4.Text == "Room 1/ Room 2/ Room 3/Room 4")
            {
                textBox4.Text = "";

                textBox4.ForeColor = Color.Black;
            }
        }

        //watermark for venue column
        private void textBox4_leave(object sender, EventArgs e)
        {
            if (textBox4.Text == "")
            {
                textBox4.Text = "Room 1/ Room 2/ Room 3/Room 4";

                textBox4.ForeColor = Color.Silver;
            }
        }

        private void textBox5_Enter(object sender, EventArgs e)
        {
            if (textBox5.Text == "More Than 0")
            {
                textBox5.Text = "";

                textBox5.ForeColor = Color.Black;
            }
        }

        private void textBox5_leave(object sender, EventArgs e)
        {
            if (textBox5.Text == "")
            {
                textBox5.Text = "More Than 0";

                textBox5.ForeColor = Color.Silver;
            }
        }

        private void button6_Click(object sender, EventArgs e)
        {
            //tutor check student in class
            Tutor_Check_Student newform = new Tutor_Check_Student();
            this.Hide();
            newform.ShowDialog();
            this.Show();
        }

        private void button_Click(object sender, EventArgs e)
        {
            //tutor check student in class
            Tutor_Check_Student newform = new Tutor_Check_Student();
            this.Hide();
            newform.ShowDialog();
            this.Show();
        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {
            this.Close();

        }
    }
}
