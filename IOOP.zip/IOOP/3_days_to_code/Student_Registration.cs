﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

//database library
using System.Data.OleDb;

namespace _3_days_to_code
{
    public partial class Student_Registration : Form
    {
        OleDbConnection connect = new OleDbConnection();
        OleDbCommand cmd = new OleDbCommand();

        public Student_Registration()
        {
            InitializeComponent();
        }

        private void Student_Registration_Load(object sender, EventArgs e)
        {
            connect.ConnectionString = "Provider = Microsoft.JET.OLEDB.4.0; Data Source = IOOP.mdb";
            connect.Open();


            tableLayoutPanel1.Parent = pictureBox1;
            tableLayoutPanel2.Parent = pictureBox1;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Staff_Dashboard newform = new Staff_Dashboard();
            this.Hide();
            newform.ShowDialog();
            this.Show();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Log_In newform = new Log_In();
            this.Hide();
            newform.ShowDialog();
            this.Show();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            string student_ID = textBox1.Text;
            string first_name = Useful_Functions.FirstCharToUpper(textBox2.Text);
            string last_name = Useful_Functions.FirstCharToUpper(textBox10.Text);
            string address = Useful_Functions.FirstCharToUpper(textBox8.Text);
                                  

            if (student_ID.Length >= 8)
            { 
                    if (comboBox1.Text == "Male" || comboBox1.Text == "Female" || comboBox1.Text == "Prefer Not To Mention")
                    {

                        if (textBox6.Text == "1" || textBox6.Text == "2" || textBox6.Text == "3" || textBox6.Text == "4")
                        {

                            if (textBox5.Text.Contains("@"))
                            {

                                switch (textBox6.Text.ToString())
                                {
                                    case "1":
                                        {
                                            cmd.CommandText = "SELECT count(Class_ID) as Number_of_Student FROM Enrollment_Data group by Class_ID having Class_ID = '" + textBox6.Text + "'";
                                            cmd.Connection = connect;

                                            connect.Close();
                                            connect.Open();

                                            //Load Data in Database
                                            OleDbDataReader reader_1 = cmd.ExecuteReader();

                                            //reader type is boolean
                                            if (reader_1.Read() == true)
                                            {
                                                if (int.Parse(reader_1[0].ToString()) < 25)
                                                {

                                                    connect.Close();
                                                    connect.Open();

                                                    int numbers = int.Parse(textBox7.Text);

                                                    string query_1 = string.Format(@"insert into Enrollment_Data values('{0}','{1}','{2}','{3}','{4}')", textBox11.Text, textBox1.Text, textBox6.Text, data.today, textBox9.Text);
                                                    string query_2 = string.Format(@"insert into User_Data values('{0}','{1}','{2}','{3}',{4},'{5}','Student','{6}','{7}','{8}',{9})", textBox1.Text, textBox1.Text, first_name, last_name, textBox7.Text, textBox5.Text, comboBox1.Text, address, textBox4.Text, textBox3.Text);
                                                    string query_3 = string.Format(@"insert into Subject_Count values('{0}','{1}','{2}')", textBox1.Text, textBox1.Text, textBox6.Text);

                                                    //Query Commands 
                                                    cmd.CommandText = query_1;

                                                    //connect to database
                                                    cmd.Connection = connect;

                                                    //execute code
                                                    cmd.ExecuteNonQuery();

                                                    

                                                    connect.Close();
                                                    connect.Open();

                                                    //Query Commands 
                                                    cmd.CommandText = query_2;

                                                    //connect to database
                                                    cmd.Connection = connect;

                                                    //execute code
                                                    cmd.ExecuteNonQuery();

                                                    

                                                    connect.Close();
                                                    connect.Open();

                                                    //Query Commands 
                                                    cmd.CommandText = query_3;

                                                    //connect to database
                                                    cmd.Connection = connect;

                                                    //execute code
                                                    cmd.ExecuteNonQuery();

                                                    try { if (cmd.ExecuteNonQuery() == 1) ; }

                                                    catch
                                                    {
                                                        MessageBox.Show("Success!");
                                                        textBox1.Text = " ";
                                                        textBox2.Text = " ";
                                                        textBox3.Text = " ";
                                                        textBox4.Text = " ";
                                                        textBox5.Text = " ";
                                                        textBox6.Text = " ";
                                                        textBox7.Text = " ";
                                                        textBox8.Text = " ";
                                                        textBox9.Text = " ";
                                                        textBox10.Text = " ";
                                                        textBox11.Text = " ";
                                                        reader_1.Close();

                                                    }
                                                }

                                                else
                                                {
                                                    MessageBox.Show(reader_1[0].ToString());
                                                    MessageBox.Show("Class Full");
                                                    textBox6.Text = " ";
                                                    reader_1.Close();
                                                }
                                            }

                                            else
                                            {
                                                MessageBox.Show("Class Full");
                                                reader_1.Close();
                                            }

                                            break;
                                        }
                                    case "2":
                                        cmd.CommandText = "SELECT count(Class_ID) as Number_of_Student FROM Enrollment_Data group by Class_ID having Class_ID = '" + textBox6.Text + "'";
                                        cmd.Connection = connect;
    
                                        connect.Close();
                                        connect.Open();

                                        //Load Data in Database
                                        OleDbDataReader reader_2 = cmd.ExecuteReader();

                                        //reader type is boolean
                                        if (reader_2.Read() == true)
                                        {
                                            if (int.Parse(reader_2[0].ToString()) < 25)
                                            {
                                                int numbers = int.Parse(textBox7.Text);

                                                connect.Close();
                                                connect.Open();

                                                string query_1 = string.Format(@"insert into Enrollment_Data values('{0}','{1}','{2}','{3}','{4}')", textBox11.Text, textBox1.Text, textBox6.Text, data.today, textBox9.Text);
                                                string query_2 = string.Format(@"insert into User_Data values('{0}','{1}','{2}','{3}',{4},'{5}','Student','{6}','{7}','{8}',{9})", textBox1.Text, textBox1.Text, first_name, last_name, textBox7.Text, textBox5.Text, comboBox1.Text, address, textBox4.Text, textBox3.Text);

                                                //Query Commands 
                                                cmd.CommandText = query_1;

                                                //connect to database
                                                cmd.Connection = connect;

                                                //execute code
                                                cmd.ExecuteNonQuery();

                                                connect.Close();
                                                connect.Open();

                                                //Query Commands 
                                                cmd.CommandText = query_2;

                                                //connect to database
                                                cmd.Connection = connect;

                                                //execute code
                                                cmd.ExecuteNonQuery();


                                                try { if (cmd.ExecuteNonQuery() == 1) ; }

                                                catch
                                                {
                                                    MessageBox.Show("Success!");
                                                    textBox1.Text = " ";
                                                    textBox2.Text = " ";
                                                    textBox3.Text = " ";
                                                    textBox4.Text = " ";
                                                    textBox5.Text = " ";
                                                    textBox6.Text = " ";
                                                    textBox7.Text = " ";
                                                    textBox8.Text = " ";
                                                    textBox9.Text = " ";
                                                    textBox10.Text = " ";
                                                    textBox11.Text = " ";
                                                    reader_2.Close();

                                                }
                                            }

                                            else
                                            {

                                                MessageBox.Show("Class Full");
                                                textBox6.Text = " ";
                                                reader_2.Close();
                                            }
                                        }

                                        break;

                                    case "3":
                                        cmd.CommandText = "SELECT count(Class_ID) as Number_of_Student FROM Enrollment_Data group by Class_ID having Class_ID = '" + textBox6.Text + "'";
                                        cmd.Connection = connect;

                                    connect.Open();
                                    connect.Close();

                                        //Load Data in Database
                                        OleDbDataReader reader_3 = cmd.ExecuteReader();

                                        //reader type is boolean
                                        if (reader_3.Read() == true)
                                        {
                                            if (int.Parse(reader_3[0].ToString()) < 25)
                                            {
                                                int numbers = int.Parse(textBox7.Text);

                                                connect.Close();
                                                connect.Open();

                                                string query_1 = string.Format(@"insert into Enrollment_Data values('{0}','{1}','{2}','{3}','{4}')", textBox11.Text, textBox1.Text, textBox6.Text, data.today, textBox9.Text);
                                                string query_2 = string.Format(@"insert into User_Data values('{0}','{1}','{2}','{3}',{4},'{5}','Student','{6}','{7}','{8}',{9})", textBox1.Text, textBox1.Text, first_name, last_name, textBox7.Text, textBox5.Text, comboBox1.Text, address, textBox4.Text, textBox3.Text);

                                                //Query Commands 
                                                cmd.CommandText = query_1;

                                                //connect to database
                                                cmd.Connection = connect;

                                                //execute code
                                                cmd.ExecuteNonQuery();

                                                connect.Close();
                                                connect.Open();

                                                //Query Commands 
                                                cmd.CommandText = query_2;

                                                //connect to database
                                                cmd.Connection = connect;

                                                //execute code
                                                cmd.ExecuteNonQuery();


                                                try { if (cmd.ExecuteNonQuery() == 1) ; }

                                                catch
                                                {
                                                    MessageBox.Show("Success!");
                                                    textBox1.Text = " ";
                                                    textBox2.Text = " ";
                                                    textBox3.Text = " ";
                                                    textBox4.Text = " ";
                                                    textBox5.Text = " ";
                                                    textBox6.Text = " ";
                                                    textBox7.Text = " ";
                                                    textBox8.Text = " ";
                                                    textBox9.Text = " ";
                                                    textBox10.Text = " ";
                                                    textBox11.Text = " ";
                                                    reader_3.Close();
                                                }
                                            }

                                            else
                                            {

                                                MessageBox.Show("Class Full");
                                                textBox6.Text = " ";
                                                reader_3.Close();
                                            }
                                        }

                                        break;
                                    case "4":



                                        cmd.CommandText = "SELECT count(Class_ID) as Number_of_Student FROM Enrollment_Data group by Class_ID having Class_ID = '" + textBox6.Text.ToString() + "'";
                                        cmd.Connection = connect;

                                    connect.Close();
                                    connect.Open();


                                    //Load Data in Database
                                    OleDbDataReader reader_one = cmd.ExecuteReader();


                                        //reader type is boolean
                                        if (reader_one.Read() == true)
                                        {
                                            if (int.Parse(reader_one[0].ToString()) < 25)
                                            {
                                                int numbers = int.Parse(textBox7.Text);


                                                connect.Close();
                                                connect.Open();

                                                string query_1 = string.Format(@"insert into Enrollment_Data values('{0}','{1}','{2}','{3}','{4}')", textBox11.Text, textBox1.Text, textBox6.Text, data.today, textBox9.Text);
                                                string query_2 = string.Format(@"insert into User_Data values('{0}','{1}','{2}','{3}',{4},'{5}','Student','{6}','{7}','{8}',{9})", textBox1.Text, textBox1.Text, first_name, last_name, textBox7.Text, textBox5.Text, comboBox1.Text, address, textBox4.Text, textBox3.Text);

                                                //Query Commands 
                                                cmd.CommandText = query_1;

                                                //connect to database
                                                cmd.Connection = connect;

                                                //execute code
                                                cmd.ExecuteNonQuery();

                                                connect.Close();
                                                connect.Open();

                                                //Query Commands 
                                                cmd.CommandText = query_2;

                                                //connect to database
                                                cmd.Connection = connect;

                                                //execute code
                                                cmd.ExecuteNonQuery();


                                                try { if (cmd.ExecuteNonQuery() == 1) ; }

                                                catch
                                                {
                                                    MessageBox.Show("Success!");
                                                    textBox1.Text = " ";
                                                    textBox2.Text = " ";
                                                    textBox3.Text = " ";
                                                    textBox4.Text = " ";
                                                    textBox5.Text = " ";
                                                    textBox6.Text = " ";
                                                    textBox7.Text = " ";
                                                    textBox8.Text = " ";
                                                    textBox9.Text = " ";
                                                    textBox10.Text = " ";
                                                    textBox11.Text = " ";
                                                    reader_one.Close();
                                                }
                                            }

                                            else
                                            {

                                                MessageBox.Show("Class Full");
                                                textBox6.Text = " ";
                                                reader_one.Close();
                                            }
                                        }

                                        else
                                        {
                                            MessageBox.Show("Error");
                                        }

                                            break;

                                }
                                                                                                                             

                            }

                        }

                        else
                        {
                            MessageBox.Show("Invalid Class");
                            textBox6.Text = " ";
                        }

                    }

                    else
                    {
                        MessageBox.Show("Please Pick a Gender");
                    }

            }

            else
            {
                MessageBox.Show("Please Insert a valid TP Number");
                textBox1.Text = " ";

            }




        }

        private void button3_Click(object sender, EventArgs e)
        {
            Staff_Class newform = new Staff_Class();
            this.Hide();
            newform.ShowDialog();
            this.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Staff_Student_Payment newform = new Staff_Student_Payment();
            this.Hide();
            newform.ShowDialog();
            this.Show();
        }

        //watermark for TP Number column
        private void textBox1_Enter(object sender, EventArgs e)
        {

            if (textBox1.Text == "TP012345")
            {
                textBox1.Text = "";

                textBox1.ForeColor = Color.Black;
            }
        }

        //watermark for TP Number column
        private void textBox1_leave(object sender, EventArgs e)
        {
            if (textBox1.Text == "")
            {
                textBox1.Text = "TP012345";

                textBox1.ForeColor = Color.Silver;
            }
        }

        //watermark for student name column
        private void textBox2_Enter(object sender, EventArgs e)
        {
            if (textBox2.Text == "Insert Student First Name")
            {
                textBox2.Text = "";

                textBox2.ForeColor = Color.Black;
            }
        }

        //watermark for student name column
        private void textBox2_leave(object sender, EventArgs e)
        {
            if (textBox2.Text == "")
            {
                textBox2.Text = "Insert Student First Name";

                textBox2.ForeColor = Color.Silver;
            }
        }

        //watermark for name column
        private void textBox3_Enter(object sender, EventArgs e)
        {
            if (textBox3.Text == "Insert Age")
            {
                textBox3.Text = "";

                textBox3.ForeColor = Color.Black;
            }
        }

        //watermark for name column
        private void textBox3_leave(object sender, EventArgs e)
        {
            if (textBox3.Text == "")
            {
                textBox3.Text = "Insert Age";

                textBox3.ForeColor = Color.Silver;
            }
        }

        //watermark for id number column
        private void textBox4_Enter(object sender, EventArgs e)
        {
            if (textBox4.Text == "Insert Identification Number")
            {
                textBox4.Text = "";

                textBox4.ForeColor = Color.Black;
            }
        }

        //watermark for id number column
        private void textBox4_leave(object sender, EventArgs e)
        {
            if (textBox4.Text == "")
            {
                textBox4.Text = "Insert Identification Number";

                textBox4.ForeColor = Color.Silver;
            }
        }

        //watermark for class column
        private void textBox6_Enter(object sender, EventArgs e)
        {
            if (textBox6.Text == "1/ 2/ 3/ 4")
            {
                textBox6.Text = "";

                textBox6.ForeColor = Color.Black;
            }
        }

        //watermark for class column
        private void textBox6_leave(object sender, EventArgs e)
        {
            if (textBox6.Text == "")
            {
                textBox6.Text = "1/ 2/ 3/ 4";

                textBox6.ForeColor = Color.Silver;
            }
        }

        //watermark for gender column
        private void comboBox1_Enter(object sender, EventArgs e)
        {
            if (comboBox1.Text == "Please Pick One")
            {
                comboBox1.Text = "";

                comboBox1.ForeColor = Color.Black;
            }
        }

        //watermark for gender column
        private void comboBox1_leave(object sender, EventArgs e)
        {
            if (comboBox1.Text == "")
            {
                comboBox1.Text = "Please Pick One";

                comboBox1.ForeColor = Color.Silver;
            }
        }

        //watermark for name column
        private void textBox5_Enter(object sender, EventArgs e)
        {
            if (textBox5.Text == "someone@mail.com")
            {
                textBox5.Text = "";

                textBox5.ForeColor = Color.Black;
            }
        }

        //watermark for name column
        private void textBox5_leave(object sender, EventArgs e)
        {
            if (textBox5.Text == "")
            {
                textBox5.Text = "someone@mail.com";

                textBox5.ForeColor = Color.Silver;
            }
        }

        //watermark for name column
        private void textBox7_Enter(object sender, EventArgs e)
        {
            if (textBox7.Text == "Insert Number without Dash")
            {
                textBox7.Text = "";

                textBox7.ForeColor = Color.Black;
            }
        }

        //watermark for name column
        private void textBox7_leave(object sender, EventArgs e)
        {
            if (textBox7.Text == "")
            {
                textBox7.Text = "Insert Number without Dash";

                textBox7.ForeColor = Color.Silver;
            }
        }

        //watermark for name column
        private void textBox8_Enter(object sender, EventArgs e)
        {
            if (textBox8.Text == "Insert Address")
            {
                textBox8.Text = "";

                textBox8.ForeColor = Color.Black;
            }
        }

        //watermark for name column
        private void textBox8_leave(object sender, EventArgs e)
        {
            if (textBox8.Text == "")
            {
                textBox8.Text = "Insert Address";

                textBox8.ForeColor = Color.Silver;
            }
        }

        //watermark for student name column
        private void textBox9_Enter(object sender, EventArgs e)
        {
            if (textBox9.Text == "Insert Student Last Name")
            {
                textBox9.Text = "";

                textBox9.ForeColor = Color.Black;
            }
        }

        //watermark for student name column
        private void textBox9_leave(object sender, EventArgs e)
        {
            if (textBox9.Text == "")
            {
                textBox9.Text = "Insert Student Last Name";

                textBox9.ForeColor = Color.Silver;
            }
        }


        //watermark for student name column
        private void textBox10_Enter(object sender, EventArgs e)
        {
            if (textBox10.Text == "Insert Student Last Name")
            {
                textBox10.Text = "";

                textBox10.ForeColor = Color.Black;
            }
        }

        //watermark for student name column
        private void textBox10_leave(object sender, EventArgs e)
        {
            if (textBox10.Text == "")
            {
                textBox10.Text = "Insert Student Last Name";

                textBox10.ForeColor = Color.Silver;
            }
        }

        //watermark for student name column
        private void textBox11_Enter(object sender, EventArgs e)
        {
            if (textBox11.Text == "xxxxxx")
            {
                textBox11.Text = "";

                textBox11.ForeColor = Color.Black;
            }
        }

        //watermark for student name column
        private void textBox11_leave(object sender, EventArgs e)
        {
            if (textBox11.Text == "")
            {
                textBox11.Text = "xxxxxx";

                textBox11.ForeColor = Color.Silver;
            }
        }

        private void button6_Click(object sender, EventArgs e)
        {
            Staff_Check_Payment newform = new Staff_Check_Payment();
            this.Hide();
            newform.ShowDialog();
            this.Show();
        }

        private void button7_Click(object sender, EventArgs e)
        {
            Staff_Enroll_More__Subjects newform = new Staff_Enroll_More__Subjects();
            this.Hide();
            newform.ShowDialog();
            this.Show();
        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
