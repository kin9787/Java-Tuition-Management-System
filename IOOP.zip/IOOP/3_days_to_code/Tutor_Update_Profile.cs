﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

//database library
using System.Data.OleDb;

namespace _3_days_to_code
{
    public partial class Tutor_Update_Profile : Form
    {

        //set up database connection
        OleDbConnection connect = new OleDbConnection();
        OleDbCommand cmd = new OleDbCommand();

        public Tutor_Update_Profile()
        {
            InitializeComponent();

            //password management
            textBox2.PasswordChar = '*';
            textBox2.MaxLength = 10;
            textBox3.PasswordChar = '*';
            textBox3.MaxLength = 10;
            textBox4.PasswordChar = '*';
            textBox4.MaxLength = 10;
        }

        private void Tutor_Update_Profile_Load(object sender, EventArgs e)
        {
            //provide database source
            connect.ConnectionString = "Provider = Microsoft.JET.OLEDB.4.0; Data Source = IOOP.mdb";

            //open connection to database
            connect.Open();
        }

        //log off
        private void button4_Click(object sender, EventArgs e)
        {
            Log_In newform = new Log_In();
            this.Hide();
            newform.ShowDialog();
            this.Show();
        }

        //take user to tutor dashboard
        private void button1_Click(object sender, EventArgs e)
        {
            Tutor_Dashboard newform = new Tutor_Dashboard();
            this.Hide();
            newform.ShowDialog();
            this.Show();
        }


        //take user to check class schedule
        private void button2_Click(object sender, EventArgs e)
        {
            Tutor_Class newform = new Tutor_Class();
            this.Hide();
            newform.ShowDialog();
            this.Show();
        }

        //able user to add class schedule
        private void button3_Click(object sender, EventArgs e)
        {
            Tutor_Add_Class newform = new Tutor_Add_Class();
            this.Hide();
            newform.ShowDialog();
            this.Show();
        }

        //watermark for username column
        private void textBox1_Enter(object sender, EventArgs e)
        {

            if (textBox1.Text == "Tutor's Username")
            {
                textBox1.Text = "";

                textBox1.ForeColor = Color.Black;
            }
        }

        //watermark for username column
        private void textBox1_leave(object sender, EventArgs e)
        {
            if (textBox1.Text == "")
            {
                textBox1.Text = "Tutor's Username";

                textBox1.ForeColor = Color.Silver;
            }
        }

        private void button5_Click_1(object sender, EventArgs e)
        {
            if (textBox2.Text != "")
            {
                //Query Commands
                cmd.CommandText = "select * from User_Data where UserID = '" + textBox1.Text + "'";
                cmd.Connection = connect;

                //read data from database
                OleDbDataReader reader = cmd.ExecuteReader();
                if (reader.Read() == true)
                {

                    //picking the password column
                    string pass = reader[1].ToString();
                    if (textBox2.Text == pass)
                    {
                        //close connection to database
                        connect.Close();
                        connect.Open();

                        //check re-type password same as new password
                        if (textBox3.Text == textBox4.Text)
                        {
                            connect.Close();
                            connect.Open();

                            //Query Commands
                            cmd.CommandText = "update User_Data set [Password] = '" + textBox3.Text + "' where UserID  = '" + textBox1.Text + "'";
                            cmd.Connection = connect;

                            //Execute Query
                            cmd.ExecuteNonQuery();
                            if (cmd.ExecuteNonQuery() == 1)
                            {
                                //if successfully update profile
                                MessageBox.Show("Done");
                                textBox1.Text = " ";
                                textBox2.Text = " ";
                                textBox3.Text = " ";
                                textBox4.Text = " ";
                            }

                            //close the connection
                            connect.Close();
                        }

                        else
                        {
                            //if user entered wrong password (re-type password column)
                            MessageBox.Show("Password not match.");
                        }
                    }

                    else
                    {
                        //if user entered wrong password
                        MessageBox.Show("Please retype your previous password.");
                        connect.Close();
                    }

                }

                else
                {
                    //if user leave Username blank
                    MessageBox.Show("Username not filled.");
                }
            }
        }

        private void button7_Click(object sender, EventArgs e)
        {
            if (textBox5.Text != "")
            {
                //Query Commands
                cmd.CommandText = "select * from User_Data where UserID = '" + textBox1.Text + "'";
                cmd.Connection = connect;

                //read data from database
                OleDbDataReader reader = cmd.ExecuteReader();
                if (reader.Read() == true)
                {

                    //picking the password column
                    string pass = reader[1].ToString();
                    if (textBox2.Text == pass)
                    {
                        //close connection to database
                        connect.Close();

                        //set email as variable
                        string email = textBox5.Text;

                        //check re-type password same as new password
                        if (email.Contains("@"))
                        {
                            connect.Open();

                            //Query Commands
                            cmd.CommandText = "update User_Data set [Email] = '" + textBox5.Text + "' where UserID  = '" + textBox1.Text + "'";
                            cmd.Connection = connect;

                            //Execute Query
                            cmd.ExecuteNonQuery();
                            if (cmd.ExecuteNonQuery() == 1)
                            {
                                //if successfully update profile
                                MessageBox.Show("Done");
                                textBox1.Text = null;
                                textBox2.Text = null;
                                textBox3.Text = null;
                                textBox4.Text = null;
                                textBox5.Text = null;
                                textBox6.Text = null;
                                textBox7.Text = null;
                                reader.Close();
                            }

                            //close the connection
                            connect.Close();
                        }

                        else
                        {
                            //if user entered wrong email
                            MessageBox.Show("Not an email.");
                        }
                    }

                    else
                    {
                        //if user entered wrong password
                        MessageBox.Show("Please retype your previous password.");
                        connect.Close();
                    }

                }

                else
                {
                    //if user leave Student_ID blank
                    MessageBox.Show("Student ID not filled.");
                }
            }
        }

        private void button9_Click(object sender, EventArgs e)
        {
            if (textBox6.Text != "")
            {
                //Query Commands
                cmd.CommandText = "select * from User_Data where UserID = '" + textBox1.Text + "'";
                cmd.Connection = connect;

                //read data from database
                OleDbDataReader reader = cmd.ExecuteReader();
                if (reader.Read() == true)
                {

                    //picking the password column
                    string pass = reader[1].ToString();
                    if (textBox2.Text == pass)
                    {
                        //close connection to database
                        connect.Close();

                        string address = Useful_Functions.FirstCharToUpper(textBox6.Text);

                        //Query Commands
                        cmd.CommandText = "update User_Data set [Address] = '" + address + "' where UserID  = '" + textBox1.Text + "'";
                        cmd.Connection = connect;

                        //Execute Query
                        cmd.ExecuteNonQuery();
                        if (cmd.ExecuteNonQuery() == 1)
                        {
                            //if successfully update profile
                            MessageBox.Show("Done");
                            textBox1.Text = null;
                            textBox2.Text = null;
                            textBox3.Text = null;
                            textBox4.Text = null;
                            textBox5.Text = null;
                            textBox6.Text = null;
                            textBox7.Text = null;
                            reader.Close();

                            //close the connection
                            connect.Close();
                        }


                    }

                    else
                    {
                        //if user entered wrong password
                        MessageBox.Show("Please retype your previous password.");
                        connect.Close();
                    }

                }

                else
                {
                    //if user leave Student_ID blank
                    MessageBox.Show("Student ID not filled.");
                }
            }
        }

        private void button8_Click(object sender, EventArgs e)
        {
            if (textBox7.Text != "")
            {
                //Query Commands
                cmd.CommandText = "select * from User_Data where UserID = '" + textBox1.Text + "'";
                cmd.Connection = connect;

                //read data from database
                OleDbDataReader reader = cmd.ExecuteReader();
                if (reader.Read() == true)
                {

                    //picking the password column
                    string pass = reader[1].ToString();
                    if (textBox2.Text == pass)
                    {
                        //close connection to database
                        connect.Close();


                        //Query Commands
                        cmd.CommandText = "update User_Data set [Contact_Number] = '" + textBox7.Text + "' where UserID  = '" + textBox1.Text + "'";
                        cmd.Connection = connect;

                        //Execute Query
                        cmd.ExecuteNonQuery();
                        if (cmd.ExecuteNonQuery() == 1)
                        {
                            //if successfully update profile
                            MessageBox.Show("Done");
                            textBox1.Text = null;
                            textBox2.Text = null;
                            textBox3.Text = null;
                            textBox4.Text = null;
                            textBox5.Text = null;
                            textBox6.Text = null;
                            textBox7.Text = null;
                            reader.Close();

                            //close the connection
                            connect.Close();
                        }



                    }

                    else
                    {
                        //if user entered wrong password
                        MessageBox.Show("Please retype your previous password.");
                        connect.Close();
                    }

                }

                else
                {
                    //if user leave Student_ID blank
                    MessageBox.Show("Student ID not filled.");
                }
            }
        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
