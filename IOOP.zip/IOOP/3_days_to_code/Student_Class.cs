﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _3_days_to_code
{
    public partial class Student_Class : Form
    {
        public Student_Class()
        {
            InitializeComponent();
        }

        //takes user to student dashboard
        private void button1_Click(object sender, EventArgs e)
        {
            Student_Dashboard newform = new Student_Dashboard();
            this.Hide();
            newform.ShowDialog();
            this.Show();
        }

        //able user to check their payment
        private void button2_Click(object sender, EventArgs e)
        {
            Student_Check_Payment newform = new Student_Check_Payment();
            this.Hide();
            newform.ShowDialog();
            this.Show();
        }

        //able user to update profile
        private void button3_Click(object sender, EventArgs e)
        {
            Student_Update_Profile newform = new Student_Update_Profile();
            this.Hide();
            newform.ShowDialog();
            this.Show();
        }

        //log off
        private void button4_Click(object sender, EventArgs e)
        {
            Log_In newform = new Log_In();
            this.Hide();
            newform.ShowDialog();
            this.Show();
        }

        //check class schedule
        private void button5_Click(object sender, EventArgs e)
        {

            string subject = Useful_Functions.FirstCharToUpper(textBox2.Text);

            if (textBox1.Text == "1" || textBox1.Text == "2" || textBox1.Text == "3" || textBox1.Text == "4")
            {
                if (subject == "Math" || subject == "English")
                {

                    keys.print_out_variable = textBox1.Text;
                    keys.print_out_variable_2 = textBox2.Text;

                    Print_out_class newform = new Print_out_class();
                    this.Hide();
                    newform.ShowDialog();
                    this.Show();
                }

                else
                {
                    MessageBox.Show("Invalid Subject");
                    textBox1.Text = null;
                    textBox2.Text = null;
                }

            }

            else
            {
                MessageBox.Show("Invalid Class");
                textBox1.Text = null;
                textBox2.Text = null;
            }
        }

        //watermark for class column
        private void textBox1_Enter(object sender, EventArgs e)
        {
            if (textBox1.Text == "1/ 2/ 3/ 4")
            {
                textBox1.Text = "";

                textBox1.ForeColor = Color.Black;
            }
        }

        //watermark for class column
        private void textBox1_leave(object sender, EventArgs e)
        {
            if (textBox1.Text == "")
            {
                textBox1.Text = "1/ 2/ 3/ 4";

                textBox1.ForeColor = Color.Silver;
            }
        }

        //watermark for subject column
        private void textBox2_leave(object sender, EventArgs e)
        {
            if (textBox2.Text == "")
            {
                textBox2.Text = "Math/ English";

                textBox2.ForeColor = Color.Silver;
            }
        }

        //watermark for subject column
        private void textBox2_Enter(object sender, EventArgs e)
        {
            if (textBox2.Text == "Math/ English")
            {
                textBox2.Text = "";

                textBox2.ForeColor = Color.Silver;
            }
        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
