﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _3_days_to_code
{
    class Useful_Functions
    {
        //Method for capitalizing Strings
        public static string FirstCharToUpper(string value)
        {
            //convert all to lowercase
            string new_value = value.ToLower();

            //convert string to char array
            char[] array = new_value.ToCharArray();
            
            // Handle the first letter in the string.  
            if (array.Length >= 1)
            {
                if (char.IsLower(array[0]))
                {
                    array[0] = char.ToUpper(array[0]);
                }
            }
            
            // Scan through the letters, checking for spaces.  
            // Uppercase the lowercase letters following spaces.  
            for (int i = 1; i < array.Length; i++)
            {
                if (array[i - 1] == ' ')
                {
                    if (char.IsLower(array[i]))
                    {
                        array[i] = char.ToUpper(array[i]);
                    }
                }

            }
            return new string(array);
        }
    }
}
