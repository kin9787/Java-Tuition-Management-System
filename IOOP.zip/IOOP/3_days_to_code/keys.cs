﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _3_days_to_code
{
    class keys
    {
        //as an indicator which member status the user picked
        public static string key_for_use = string.Empty;
        
        //as a key for choosing class schedule
        public static string print_out_variable = string.Empty;
        
        //as another key for choosing class variable
        public static string print_out_variable_2 = string.Empty;

        //variable for name
        public static string name_for_dashboard = string.Empty;

        //variable for name
        public static string Student_ID = string.Empty;

        //variable for name
        public static string Staff_Name = string.Empty;

        //variable for name
        public static string Amount = string.Empty;

        //variable for name
        public static string Class = string.Empty;
    }
}
