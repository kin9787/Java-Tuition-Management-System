﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

//Library for Database
using System.Data.OleDb;

namespace _3_days_to_code
{
    public partial class Log_In : Form
    {
        //Seting up connection for MS Access
        OleDbConnection connect = new OleDbConnection();
        OleDbCommand cmd = new OleDbCommand();

        public Log_In()
        {
            InitializeComponent();
            
            //Hide Password Characters
            textBox2.PasswordChar = '*';
            textBox2.MaxLength = 10;
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            //Setting up Database Source
            connect.ConnectionString = "Provider = Microsoft.JET.OLEDB.4.0; Data Source = IOOP.mdb";
            
            //connect to database
            connect.Open();
            
            
        }

        private void button1_Click(object sender, EventArgs e)
        {
            // Username Textbox
            string input_1 = textBox1.Text;
            
           
            //As an indicator for wrong password
            int locking = 0;

            if (input_1.Contains("@"))
            {
                //if user enter email
                MessageBox.Show("Username please, not email.");
                textBox1.Text = null;
                textBox2.Text = null;
                
            }

            else
            {

                //open a new connection
                connect.Close();
                connect.Open();

                //Query Commands (Select user role from Database)
                cmd.CommandText = "select * from User_Data where UserID= '" + input_1 + "'";
                cmd.Connection = connect;

                //Load Data in Database
                OleDbDataReader reader = cmd.ExecuteReader();

                if (reader.Read() == true)
                {
                    string roles = reader[6].ToString();
                    if (comboBox1.Text == reader[6].ToString())
                    {
                        //close reader
                        reader.Close();

                        //If user pick Staff as log in status
                        if (comboBox1.Text == "Staff")
                        {
                            //A key to be bring to next form through the keys.cs class
                            keys.key_for_use = comboBox1.Text;

                            //name to be used in dashboard
                            keys.name_for_dashboard = textBox1.Text;

                            //disconnect from database
                            connect.Close();

                            //connect to database
                            connect.Open();

                            //Query Commands (Select user role from Database)
                            cmd.CommandText = "select * from User_Data where UserID= '" + input_1 + "'";
                            cmd.Connection = connect;

                            //Load Data in Database
                            OleDbDataReader reader_1 = cmd.ExecuteReader();

                            //reader type is boolean
                            if (reader_1.Read() == true)
                            {
                                //Variable as Password
                                string pass = reader_1[1].ToString();
                                if (textBox2.Text == pass)
                                {
                                    //takes user to the Staff Dashboard
                                    Staff_Dashboard newform = new Staff_Dashboard();
                                    this.Hide();
                                    newform.ShowDialog();
                                    this.Show();
                                    reader_1.Close();
                                }

                                else
                                {
                                    //If the user typed the wrong password
                                    MessageBox.Show("Invalid Password.");
                                    textBox1.Text = null;
                                    textBox2.Text = null;
                                    locking = 1;
                                    reader_1.Close();
                                }

                            }

                            else
                            {
                                //If database does not contain the user
                                MessageBox.Show("User not found");
                                textBox1.Text = null;
                                textBox2.Text = null;
                                reader_1.Close();
                            }


                        }

                        //If the user choose Student as Log In status
                        else if (comboBox1.Text == "Student")
                        {
                            //A key to be bring to next form through the keys.cs class
                            keys.key_for_use = comboBox1.Text;

                            //name to be used in dashboard
                            keys.name_for_dashboard = textBox1.Text;

                            //disconnect from database
                            connect.Close();

                            //connect to database
                            connect.Open();

                            //Query Commands (Select user role from Database)
                            cmd.CommandText = "select * from User_Data where UserID= '" + input_1 + "'";
                            cmd.Connection = connect;

                            //Load Data in Database
                            OleDbDataReader reader_2 = cmd.ExecuteReader();


                            //reader type is boolean
                            if (reader_2.Read() == true)
                            {
                                //Variable as Password
                                string pass = reader_2[1].ToString();
                                if (textBox2.Text == pass)
                                {
                                    //takes user to the Student Dashboard
                                    Student_Dashboard newform = new Student_Dashboard();
                                    this.Hide();
                                    newform.ShowDialog();
                                    this.Show();
                                    reader_2.Close();
                                }

                                else
                                {
                                    //If the user typed the wrong password
                                    MessageBox.Show("Invalid Password.");
                                    textBox1.Text = null;
                                    textBox2.Text = null;
                                    locking = 1;
                                    reader_2.Close();

                                }
                            }

                            else
                            {
                                //If database does not contain the user
                                MessageBox.Show("User not found");
                                textBox1.Text = null;
                                textBox2.Text = null;
                                reader_2.Close();
                            }
                        }

                        //If the user choose Tutor as Log In status
                        else if (comboBox1.Text == "Tutor")
                        {
                            //A key to be bring to next form through the keys.cs class
                            keys.key_for_use = comboBox1.Text;

                            //name to be used in dashboard
                            keys.name_for_dashboard = textBox1.Text;

                            //disconnect from database
                            connect.Close();

                            //connect to database
                            connect.Open();

                            //Query Commands (Select user role from Database)
                            cmd.CommandText = "select * from User_Data where UserID= '" + input_1 + "'";
                            cmd.Connection = connect;

                            //Load Data in Database
                            OleDbDataReader reader_3 = cmd.ExecuteReader();

                            //reader type is boolean
                            if (reader_3.Read() == true)
                            {
                                //Variable as Password
                                string pass = reader_3[1].ToString();
                                if (textBox2.Text == pass)
                                {
                                    //takes user to the Tutor Dashboard
                                    Tutor_Dashboard newform = new Tutor_Dashboard();
                                    this.Hide();
                                    newform.ShowDialog();
                                    this.Show();
                                    reader_3.Close();
                                }

                                else
                                {
                                    //If the user typed the wrong password
                                    MessageBox.Show("Invalid Password.");
                                    textBox1.Text = null;
                                    textBox2.Text = null;
                                    locking = 1;
                                    reader_3.Close();

                                }
                            }

                            else
                            {
                                //If database does not contain the user
                                MessageBox.Show("User not found");
                                textBox1.Text = null;
                                textBox2.Text = null;
                                reader_3.Close();
                            }

                        }

                        else
                        {
                            if (locking == 1)
                            {
                                //If the user typed in invalid password
                                MessageBox.Show("Invalid Password or Username");
                                locking = 0;
                                textBox1.Focus();
                            }

                            else
                            {
                                //If the user did not choose its log in status
                                MessageBox.Show("Please choose your member status");
                                textBox1.Focus();
                            }
                        }
                    }
               
                    
                }

                else
                {
                    MessageBox.Show("Invalid Member Status");
                    reader.Close();
                }
                                                
            }

            
        }

        //watermark for name column
        private void textBox1_Enter(object sender, EventArgs e)
        {
            if (textBox1.Text == "Insert Name Here")
            {
                textBox1.Text = "";

                textBox1.ForeColor = Color.Black;
            }
        }

        //watermark for name column
        private void textBox1_leave(object sender, EventArgs e)
        {
            if (textBox1.Text == "")
            {
                textBox1.Text = "Insert Name Here";

                textBox1.ForeColor = Color.Silver;
            }
        }

       
        //watermark for status column
        private void comboBox1_Enter(object sender, EventArgs e)
        {
            if (comboBox1.Text == "Please Choose Your Log In Status")
            {
                comboBox1.Text = "";

                comboBox1.ForeColor = Color.Black;
            }
        }

        //watermark for status column
        private void comboBox1_leave(object sender, EventArgs e)
        {
            if (comboBox1.Text == "")
            {
                comboBox1.Text = "Please Choose Your Log In Status";

                comboBox1.ForeColor = Color.Silver;
            }
        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
