﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _3_days_to_code
{
    class data
    {
        //desciption for math
        public static string Math = "Playing with Numbers";

        //description for english
        public static string English = "A famous well-known language";

        //today's date
        public static DateTime today = DateTime.Today;
    }
}
