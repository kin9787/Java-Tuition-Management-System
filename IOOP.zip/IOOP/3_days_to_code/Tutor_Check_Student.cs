﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using System.Data.OleDb;

namespace _3_days_to_code
{
    public partial class Tutor_Check_Student : Form
    {

        //Seting up connection for MS Access
        OleDbConnection connect = new OleDbConnection();
        OleDbCommand cmd = new OleDbCommand();

        public Tutor_Check_Student()
        {
            InitializeComponent();
        }

        private void Staff_Check_Payment_Load(object sender, EventArgs e)
        {
            //Setting up Database Source
            connect.ConnectionString = "Provider = Microsoft.JET.OLEDB.4.0; Data Source = IOOP.mdb";

            //connect to database
            connect.Open();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            cmd.Connection = connect;

            string query = "SELECT Enrollment_Data.Student_ID, User_Data.First_Name, User_Data.Last_Name FROM Enrollment_Data INNER JOIN User_Data ON User_Data.UserID = Enrollment_Data.Student_ID WHERE Enrollment_Data.Class_ID = '" + textBox1.Text + "'";
            cmd.CommandText = query;

            OleDbDataAdapter data_adapter = new OleDbDataAdapter(cmd);
            DataTable data_table = new DataTable();
            data_adapter.Fill(data_table);
            dataGridView1.DataSource = data_table;

        }

        private void button6_Click(object sender, EventArgs e)
        {
            Tutor_Dashboard newform = new Tutor_Dashboard();
            this.Hide();
            newform.ShowDialog();
            this.Show();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            Tutor_Class newform = new Tutor_Class();
            this.Hide();
            newform.ShowDialog();
            this.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Tutor_Add_Class newform = new Tutor_Add_Class();
            this.Hide();
            newform.ShowDialog();
            this.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Tutor_Update_Profile newform = new Tutor_Update_Profile();
            this.Hide();
            newform.ShowDialog();
            this.Show();
        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {
            this.Close();

        }
    }
}
