﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

//database library
using System.Data.OleDb;

namespace _3_days_to_code
{
    public partial class Print_out_class : Form
    {

        //set up connection for database
        OleDbConnection connect = new OleDbConnection();
        OleDbCommand cmd = new OleDbCommand();

        public Print_out_class()
        {
            InitializeComponent();

            //setting up database 
            connect.ConnectionString = "Provider = Microsoft.JET.OLEDB.4.0; Data Source = IOOP.mdb";

            //connect to database
            connect.Open();
        }

        private void button1_Click(object sender, EventArgs e)
        {

            //return to previous student class checking form
            if (keys.key_for_use == "Student")
            {
                Student_Class newform = new Student_Class();
                this.Hide();
                newform.ShowDialog();
                this.Show();
            }
            
            //return to previous staff class checking form
            else if (keys.key_for_use == "Staff")
            {
                Staff_Class newform = new Staff_Class();
                this.Hide();
                newform.ShowDialog();
                this.Show();
            }


            //return to previous tutor class checking form
            else if (keys.key_for_use == "Tutor")
            {
                Tutor_Class newform = new Tutor_Class();
                this.Hide();
                newform.ShowDialog();
                this.Show();
            }
        }

        
        private void Print_out_class_Load_1(object sender, EventArgs e)
        {
            //customize the data time
            string date_1 = DateTime.Now.ToString("dd/MM/yyyy");

            //to be connect with another string to make into date that is 7 days in the future
            date_1.Remove(0,1);
            string date_2 = "";

            //to check the date for each month by odd number
            if (int.Parse(date_1.Substring(3, 2)) == 1 || int.Parse(date_1.Substring(3, 2)) == 3 || int.Parse(date_1.Substring(3, 2)) == 5 || int.Parse(date_1.Substring(3, 2)) == 7 || int.Parse(date_1.Substring(3, 2)) == 9 || int.Parse(date_1.Substring(3, 2)) == 11)
            {
                int date_manipulation;
                date_manipulation = int.Parse(date_1.Substring(0, 1)) + 7;
                if (date_manipulation < 10)
                {
                    date_2 = "0" + date_manipulation.ToString() + date_1.Substring(2, 8);
                }

                else
                {
                    date_2 = date_manipulation.ToString() + date_1.Substring(2, 8);
                }


            }


            //to check the date for each month by even number
            else if(int.Parse(date_1.Substring(3, 2)) == 2 || int.Parse(date_1.Substring(3, 2)) == 4 || int.Parse(date_1.Substring(3, 2)) == 6 || int.Parse(date_1.Substring(3, 2)) == 8 || int.Parse(date_1.Substring(3, 2)) == 10 || int.Parse(date_1.Substring(3, 2)) == 12)
            {
                int date_manipulation;
                date_manipulation = int.Parse(date_1.Substring(0, 1)) + 7;

                if (date_manipulation < 10)
                {
                    date_2 ="0" + date_manipulation.ToString() + date_1.Substring(2, 8);
                }

                else
                {
                    date_2 = date_manipulation.ToString() + date_1.Substring(2, 8);
                }


            }


            cmd.Connection = connect;

            //Query Commnad
            cmd.CommandText = "SELECT Class.* FROM Class WHERE (((Class.Class_ID)='"+ keys.print_out_variable +"') AND ((Class.Class_Time)>=#"+date_1 +"# And (Class.Class_Time)<=#"+date_2+"#));" ;

            OleDbDataAdapter data_adapter = new OleDbDataAdapter(cmd);
            DataTable data_table = new DataTable();
            data_adapter.Fill(data_table);
            dataGridView1.DataSource = data_table;
        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
