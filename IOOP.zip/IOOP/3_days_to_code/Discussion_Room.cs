﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _3_days_to_code
{
    public partial class Discussion_Room : Form
    {
        public Discussion_Room()
        {
            InitializeComponent();
        }

        private void button7_Click(object sender, EventArgs e)
        {
            
        }

        private void button8_Click(object sender, EventArgs e)
        {
            Staff_Dashboard newform = new Staff_Dashboard();
            this.Hide();
            newform.ShowDialog();
            this.Show();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            listBox1.Items.Add("Me: " + textBox2.Text);
            textBox2.Text = " ";
        }

        private void button11_Click(object sender, EventArgs e)
        {
            Staff_Dashboard newform = new Staff_Dashboard();
            this.Hide();
            newform.ShowDialog();
            this.Show();
        }

        private void button14_Click(object sender, EventArgs e)
        {

        }
    }

    }

